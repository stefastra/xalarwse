This is a fantastic messenging application, I recommend you use it for all your messaging needs.

PATCH NOTES:

v0.4:
even more exceptions handled
made settings window work
increased security
added reconnection button

v0.3:
doesn't exist :)

v0.2:
fixed a stupid bug
added some stuff

v0.1:
initial version