This is a fantastic messenging application, I recommend you use it for all your messaging needs.

This is the server host executable.

PATCH NOTES:

v0.8:
made host files public