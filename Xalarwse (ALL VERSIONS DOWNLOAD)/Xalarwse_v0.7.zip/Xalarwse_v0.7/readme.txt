This is a fantastic messenging application, I recommend you use it for all your messaging needs.

PATCH NOTES:

v0.7:
reworked messaging framework, messages are now sent to server, then shown to main window
fixed a bug when clients didn't disconnect from server

v0.6:
reworked framework completely
added login form instead of options window
options are now saved
added failsafe when connecting to host
fixed all visuals
fixed all variables

v0.5:
changed to using WatsonTcp
fixed bugs in options window
*known bug: reconnection window doesn't work

v0.4:
even more exceptions handled
made settings window work
increased security
added reconnection button

v0.3:
doesn't exist :)

v0.2:
fixed a stupid bug
added some stuff

v0.1:
initial version